import nltk
nltk.boolean_ops()
