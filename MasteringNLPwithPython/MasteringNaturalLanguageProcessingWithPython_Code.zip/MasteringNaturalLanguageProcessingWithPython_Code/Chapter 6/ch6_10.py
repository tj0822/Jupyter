import nltk
nltk.tag.hmm.demo_pos()
