This book is for intermediate level developers in NLP with a reasonable knowledge level and understanding of Python.
For all the chapters, Python 2.7 or 3.2+ is used. NLTK 3.0 mustbe installed either on a 32-bit machine or 64-bit machine. The operating system that is required is Windows/Mac/Unix.

