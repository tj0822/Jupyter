import nltk
print(nltk.help.upenn_tagset('NNS'))
