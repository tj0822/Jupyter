import nltk
tag={}
print(tag)
tag['beautiful']='ADJ'

tag['boy']='N'
tag['read']='V'
tag['generously']='ADV'
print(tag)

