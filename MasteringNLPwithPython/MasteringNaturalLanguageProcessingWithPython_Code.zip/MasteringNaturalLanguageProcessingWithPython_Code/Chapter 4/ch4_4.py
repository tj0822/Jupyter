import nltk
text=nltk.word_tokenize("I cannot bear the pain of bear")
print(nltk.pos_tag(text))
