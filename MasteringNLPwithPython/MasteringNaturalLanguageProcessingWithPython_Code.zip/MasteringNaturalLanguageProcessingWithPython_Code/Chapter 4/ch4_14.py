import nltk
from nltk.corpus import names
print(len(names.words('male.txt')))
print(len(names.words('female.txt')))

