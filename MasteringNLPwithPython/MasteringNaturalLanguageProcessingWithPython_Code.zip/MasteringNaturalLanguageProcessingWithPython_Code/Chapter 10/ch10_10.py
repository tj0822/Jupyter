import nltk
from nltk.stem.lancaster import LancasterStemmer
stri=LancasterStemmer()
print(stri.stem('achievement'))
