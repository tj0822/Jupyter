import nltk
gram1 = nltk.data.load('grammars/large_grammars/atis.cfg')
print(gram1)

