import nltk
from nltk.probability import FreqDist
from nltk.corpus import treebank
fd = FreqDist()
print(fd.items())

