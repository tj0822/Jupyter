from nltk.corpus import stopwords
print(stopwords.fileids())
