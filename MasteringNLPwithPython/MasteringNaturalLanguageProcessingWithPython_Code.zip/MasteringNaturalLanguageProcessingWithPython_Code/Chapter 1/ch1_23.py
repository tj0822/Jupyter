text='HARdWork IS KEy to SUCCESS'
print(text.lower())
print(text.upper())
