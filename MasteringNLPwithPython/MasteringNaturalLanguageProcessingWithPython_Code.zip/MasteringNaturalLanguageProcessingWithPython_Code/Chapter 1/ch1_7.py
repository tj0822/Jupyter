import nltk
text=nltk.word_tokenize(" Don't hesitate to ask questions")
print(text)
