import nltk
from nltk import word_tokenize
r=input("Please write a text")
print("The length of text is",len(word_tokenize(r)),"words")
