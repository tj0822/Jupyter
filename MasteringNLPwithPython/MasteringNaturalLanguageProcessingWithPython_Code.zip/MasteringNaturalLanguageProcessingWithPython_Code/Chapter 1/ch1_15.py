import nltk
sent= "She secured 90.56 % in class X. She is a meritorious student"
print(sent.split())
print(sent.split(' '))
sent=" She secured 90.56 % in class X \n. She is a meritorious student\n"
print(sent.split('\n'))
